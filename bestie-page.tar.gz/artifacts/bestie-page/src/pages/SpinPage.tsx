import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useLocation } from "wouter";

/* ─── Rewards ─── */
const SEGMENTS = [
  { emoji: "🍦", label: "Ice Cream Date!", color: "#FF6B9D" },
  { emoji: "🎮", label: "Game Night!", color: "#A855F7" },
  { emoji: "🐱", label: "Cat Cuddles!", color: "#F97316" },
  { emoji: "💕", label: "Bestie Hug!", color: "#EC4899" },
  { emoji: "👑", label: "Princess of the Day!", color: "#FFD700" },
  { emoji: "✨", label: "You're Amazing!", color: "#38BDF8" },
  { emoji: "🎀", label: "BFF Forever!", color: "#10B981" },
  { emoji: "🌟", label: "You're a Star!", color: "#8B5CF6" },
];

const SEG_COUNT = SEGMENTS.length;
const SEG_DEG = 360 / SEG_COUNT; // 45°
const CX = 250, CY = 250, R = 220, INNER = 52;

const COLORS = ["#FF2D78","#A855F7","#FFD700","#3B82F6","#10B981","#F97316","#EC4899","#8B5CF6"];

/* ─── Polar helpers ─── */
function polar(cx: number, cy: number, r: number, angleDeg: number) {
  const rad = ((angleDeg - 90) * Math.PI) / 180;
  return { x: cx + r * Math.cos(rad), y: cy + r * Math.sin(rad) };
}

function segPath(i: number) {
  const start = i * SEG_DEG;
  const end = start + SEG_DEG;
  const s = polar(CX, CY, R, start);
  const e = polar(CX, CY, R, end);
  return `M ${CX} ${CY} L ${s.x.toFixed(2)} ${s.y.toFixed(2)} A ${R} ${R} 0 0 1 ${e.x.toFixed(2)} ${e.y.toFixed(2)} Z`;
}

/* ─── Mini confetti burst ─── */
function Confetti({ active }: { active: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    if (!active) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    const cx = canvas.width / 2, cy = canvas.height / 2;
    const parts = Array.from({ length: 180 }, (_, i) => {
      const a = Math.random() * Math.PI * 2;
      const spd = 8 + Math.random() * 14;
      return { x: cx, y: cy, vx: Math.cos(a) * spd, vy: Math.sin(a) * spd - 5,
        color: COLORS[i % COLORS.length], size: 7 + Math.random() * 9, id: i };
    });
    let frame = 0; let id: number;
    function draw() {
      if (!ctx || !canvas) return;
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      parts.forEach(p => {
        p.x += p.vx; p.y += p.vy; p.vy += 0.4; p.vx *= 0.98;
        ctx.globalAlpha = Math.max(0, 1 - frame / 85);
        ctx.fillStyle = p.color;
        ctx.beginPath();
        if (p.id % 2 === 0) ctx.arc(p.x, p.y, p.size / 2, 0, Math.PI * 2);
        else ctx.fillRect(p.x, p.y, p.size, p.size / 2);
        ctx.fill();
      });
      frame++;
      if (frame < 90) id = requestAnimationFrame(draw);
      else ctx.clearRect(0, 0, canvas.width, canvas.height);
    }
    id = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(id);
  }, [active]);
  return <canvas ref={canvasRef} className="fixed inset-0 pointer-events-none z-[80]" />;
}

/* ─── Wheel SVG (static segments, rotated via CSS on wrapper) ─── */
function WheelFace() {
  return (
    <svg viewBox="0 0 500 500" className="w-full h-full" style={{ display: "block" }}>
      {/* Segments */}
      {SEGMENTS.map((seg, i) => {
        const midAngle = i * SEG_DEG + SEG_DEG / 2;
        const labelR = R * 0.64;
        const emojiR = R * 0.87;
        const lp = polar(CX, CY, labelR, midAngle);
        const ep = polar(CX, CY, emojiR, midAngle);
        return (
          <g key={i}>
            <path d={segPath(i)} fill={seg.color} stroke="#fff" strokeWidth="3" />
            <text
              x={lp.x} y={lp.y}
              textAnchor="middle" dominantBaseline="middle"
              fontSize="12" fontWeight="800"
              fill={seg.color === "#FFD700" ? "#1a1a2e" : "#fff"}
              fontFamily="Boogaloo, cursive"
              transform={`rotate(${midAngle}, ${lp.x}, ${lp.y})`}
              style={{ userSelect: "none", pointerEvents: "none" }}
            >
              {seg.label.length > 13 ? seg.label.slice(0, 12) + "…" : seg.label}
            </text>
            <text
              x={ep.x} y={ep.y}
              textAnchor="middle" dominantBaseline="middle"
              fontSize="24"
              transform={`rotate(${midAngle}, ${ep.x}, ${ep.y})`}
              style={{ userSelect: "none", pointerEvents: "none" }}
            >
              {seg.emoji}
            </text>
          </g>
        );
      })}

      {/* Dividers */}
      {SEGMENTS.map((_, i) => {
        const p = polar(CX, CY, R, i * SEG_DEG);
        return <line key={i} x1={CX} y1={CY} x2={p.x.toFixed(2)} y2={p.y.toFixed(2)} stroke="#fff" strokeWidth="3" />;
      })}

      {/* Outer ring */}
      <circle cx={CX} cy={CY} r={R} fill="none" stroke="#fff" strokeWidth="5" />

      {/* Hub */}
      <circle cx={CX} cy={CY} r={INNER} fill="white" stroke="#1a1a2e" strokeWidth="4" />
      <text x={CX} y={CY} textAnchor="middle" dominantBaseline="middle" fontSize="32" style={{ userSelect: "none" }}>🎀</text>
    </svg>
  );
}

/* ─── Pointer (fixed, separate from wheel) ─── */
function Pointer() {
  // Sits at the top-center of the wheel area, pointing down
  return (
    <svg
      viewBox="0 0 500 500"
      className="absolute inset-0 w-full h-full pointer-events-none"
      style={{ zIndex: 10 }}
    >
      {/* Drop shadow */}
      <polygon
        points={`${CX - 18},${CY - R - 8} ${CX + 18},${CY - R - 8} ${CX},${CY - R + 30}`}
        fill="rgba(0,0,0,0.2)"
        transform="translate(2,3)"
      />
      {/* Pointer */}
      <polygon
        points={`${CX - 18},${CY - R - 8} ${CX + 18},${CY - R - 8} ${CX},${CY - R + 30}`}
        fill="#FF2D78"
        stroke="white"
        strokeWidth="3"
        strokeLinejoin="round"
      />
    </svg>
  );
}

/* ─── Main SpinPage ─── */
export default function SpinPage() {
  const [, setLocation] = useLocation();
  const [rotation, setRotation] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [winner, setWinner] = useState<number | null>(null);
  const [showWinner, setShowWinner] = useState(false);
  const [confettiActive, setConfettiActive] = useState(false);
  const rotationRef = useRef(0);
  const animRef = useRef<number | null>(null);

  function spin() {
    if (spinning) return;
    setWinner(null);
    setShowWinner(false);

    // Pick a random winner segment
    const W = Math.floor(Math.random() * SEG_COUNT);
    const offset = 8 + Math.random() * 29; // land in middle area of segment

    // We want: after rotation, the segment at the TOP (under pointer) = W
    // Segment W is at the top when the wheel's effective angle puts W under 0°
    // With CSS rotate(Rdeg): the top of the wheel is at (-R) mod 360
    // Segment W occupies [W*SEG_DEG, (W+1)*SEG_DEG)
    // So we need (-R) mod 360 ∈ [W*SEG_DEG, (W+1)*SEG_DEG)
    // => R mod 360 = (360 - W*SEG_DEG - offset) mod 360

    const targetNorm = W * SEG_DEG + offset;
    const targetMod = (360 - targetNorm % 360 + 360) % 360;
    const currentMod = ((rotationRef.current % 360) + 360) % 360;
    let delta = targetMod - currentMod;
    if (delta <= 0) delta += 360; // always move forward

    const finalRotation = rotationRef.current + 5 * 360 + delta;

    const startR = rotationRef.current;
    const totalDelta = finalRotation - startR;
    const duration = 4200;
    let startTime: number | null = null;

    function easeOut(t: number) {
      // Cubic ease out for natural deceleration
      return 1 - Math.pow(1 - t, 3);
    }

    setSpinning(true);

    function frame(now: number) {
      if (!startTime) startTime = now;
      const elapsed = now - startTime;
      const t = Math.min(elapsed / duration, 1);
      const current = startR + totalDelta * easeOut(t);
      rotationRef.current = current;
      setRotation(current);

      if (t < 1) {
        animRef.current = requestAnimationFrame(frame);
      } else {
        rotationRef.current = finalRotation;
        setRotation(finalRotation);
        setSpinning(false);
        setWinner(W);
        setTimeout(() => {
          setShowWinner(true);
          setConfettiActive(true);
          setTimeout(() => setConfettiActive(false), 100);
        }, 400);
      }
    }

    animRef.current = requestAnimationFrame(frame);
  }

  function reset() {
    setShowWinner(false);
    setWinner(null);
  }

  useEffect(() => () => { if (animRef.current) cancelAnimationFrame(animRef.current); }, []);

  return (
    <div
      className="min-h-screen flex flex-col items-center px-4 py-8 relative overflow-hidden"
      style={{
        background: "linear-gradient(135deg, hsl(320 100% 95%), hsl(280 90% 92%), hsl(45 100% 93%))",
        backgroundAttachment: "fixed",
      }}
    >
      <Confetti active={confettiActive} />

      {/* Background stars */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        {Array.from({ length: 14 }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute font-display"
            style={{ left: `${(i*17+5)%100}%`, top: `${(i*23+10)%100}%`,
              color: COLORS[i % COLORS.length], opacity: 0.15,
              fontSize: 14 + (i%5)*5 }}
            animate={{ opacity: [0.1, 0.3, 0.1], scale: [1, 1.4, 1] }}
            transition={{ duration: 3+(i%4), repeat: Infinity, delay: i*0.3 }}
          >
            {i%3===0?"★":i%3===1?"✦":"♡"}
          </motion.div>
        ))}
      </div>

      {/* Back button */}
      <motion.button
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setLocation("/")}
        className="self-start relative z-10 mb-6 bg-white font-display text-xl px-6 py-3 rounded-2xl flex items-center gap-2 cursor-pointer"
        style={{ border: "3px solid hsl(330 60% 15%)", boxShadow: "4px 4px 0 hsl(330 60% 15%)" }}
        data-testid="back-button"
      >
        ← Back
      </motion.button>

      {/* Title */}
      <motion.h1
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ type: "spring", bounce: 0.5 }}
        className="relative z-10 font-display text-5xl md:text-7xl text-center mb-2"
        style={{ color: "hsl(336 100% 55%)", WebkitTextStroke: "2px hsl(330 60% 15%)", paintOrder: "stroke fill" }}
        data-testid="spin-title"
      >
        🎡 Spin the Wheel!
      </motion.h1>
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="relative z-10 font-bold text-lg text-center mb-8"
        style={{ color: "hsl(330 30% 40%)" }}
      >
        Spin to reveal your bestie reward ✨
      </motion.p>

      {/* Wheel container */}
      <div className="relative z-10 w-full max-w-[340px] md:max-w-[400px] aspect-square">
        {/* CSS rotation wrapper — this is the ONLY thing that rotates */}
        <div
          className="absolute inset-0"
          style={{
            transform: `rotate(${rotation}deg)`,
            transformOrigin: "center center",
            willChange: "transform",
          }}
        >
          <WheelFace />
        </div>

        {/* Pointer sits on top and never rotates */}
        <Pointer />
      </div>

      {/* Spin button */}
      <motion.button
        onClick={spin}
        disabled={spinning}
        whileHover={spinning ? {} : { scale: 1.08, rotate: -2 }}
        whileTap={spinning ? {} : { scale: 0.93 }}
        animate={spinning ? {} : { scale: [1, 1.04, 1] }}
        transition={{ duration: 1.8, repeat: Infinity }}
        className="relative z-10 mt-10 font-display text-3xl md:text-4xl text-white px-14 py-5 rounded-3xl cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed"
        style={{
          background: spinning
            ? "hsl(330 30% 70%)"
            : "linear-gradient(135deg, hsl(336 100% 55%), hsl(280 90% 65%))",
          border: "3px solid hsl(330 60% 15%)",
          boxShadow: spinning ? "none" : "6px 6px 0 hsl(330 60% 15%)",
        }}
        data-testid="spin-button"
      >
        {spinning ? "Spinning… 🌀" : "SPIN! 🎯"}
      </motion.button>

      {/* Winner modal */}
      <AnimatePresence>
        {showWinner && winner !== null && (
          <motion.div
            className="fixed inset-0 z-[90] flex items-center justify-center p-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={reset} />

            <motion.div
              initial={{ scale: 0.4, opacity: 0, rotate: -12 }}
              animate={{ scale: 1, opacity: 1, rotate: [-4, 3, -1, 0] }}
              exit={{ scale: 0.5, opacity: 0 }}
              transition={{ type: "spring", bounce: 0.6, duration: 0.6 }}
              className="relative z-10 bg-white rounded-3xl p-10 md:p-14 max-w-md w-full text-center"
              style={{ border: "4px solid hsl(330 60% 15%)", boxShadow: "10px 10px 0 hsl(330 60% 15%)" }}
              data-testid="winner-card"
            >
              <div className="text-sm font-bold uppercase tracking-widest mb-4" style={{ color: "hsl(330 30% 50%)" }}>
                🎉 You won!
              </div>

              <motion.div
                animate={{ scale: [1, 1.2, 1], rotate: [0, 10, -10, 0] }}
                transition={{ duration: 1.5, repeat: Infinity }}
                className="text-8xl mb-6"
              >
                {SEGMENTS[winner].emoji}
              </motion.div>

              <h2
                className="font-display text-4xl md:text-5xl mb-3"
                style={{ color: SEGMENTS[winner].color, WebkitTextStroke: "1px hsl(330 60% 15%)", paintOrder: "stroke fill" }}
              >
                {SEGMENTS[winner].label}
              </h2>

              <p className="font-bold text-lg mb-8" style={{ color: "hsl(330 30% 40%)" }}>
                This reward is officially yours! 💕 Claim it from your bestie!
              </p>

              <div className="flex justify-center gap-2 mb-8">
                {COLORS.slice(0, 6).map((c, i) => (
                  <motion.div key={i} animate={{ y: [0, -10, 0] }}
                    transition={{ duration: 0.8 + i*0.1, repeat: Infinity, delay: i*0.1 }}
                    className="w-3 h-3 rounded-full" style={{ backgroundColor: c }}
                  />
                ))}
              </div>

              <div className="flex gap-4 justify-center flex-wrap">
                <motion.button
                  whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
                  onClick={reset}
                  className="font-display text-xl text-white px-8 py-3 rounded-2xl cursor-pointer"
                  style={{ background: "hsl(336 100% 55%)", border: "3px solid hsl(330 60% 15%)", boxShadow: "4px 4px 0 hsl(330 60% 15%)" }}
                  data-testid="spin-again-button"
                >
                  Spin Again! 🎡
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
                  onClick={() => setLocation("/")}
                  className="font-display text-xl px-8 py-3 rounded-2xl cursor-pointer bg-white"
                  style={{ border: "3px solid hsl(330 60% 15%)", boxShadow: "4px 4px 0 hsl(330 60% 15%)" }}
                >
                  ← Go Home
                </motion.button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
